/*
 * testSHM_types.h
 *
 * Real-Time Workshop code generation for Simulink model "testSHM.mdl".
 *
 * Model Version              : 1.5
 * Real-Time Workshop version : 7.2  (R2008b)  04-Aug-2008
 * C source code generated on : Fri Dec 10 10:34:20 2010
 */
#ifndef RTW_HEADER_testSHM_types_h_
#define RTW_HEADER_testSHM_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct Parameters_testSHM_ Parameters_testSHM;

/* Forward declaration for rtModel */
typedef struct RT_MODEL_testSHM RT_MODEL_testSHM;

#endif                                 /* RTW_HEADER_testSHM_types_h_ */
