#define SHMNAM_IN "SHMIN"
#define SHMNAM_OUT "SHMOUT"

struct comStruc_IN
{
	int index_counter;
	float sin_value;
	float cos_value;
};

struct comStruc_OUT
{
	int index_counter;
	float sin_value;
	float cos_value;
};
